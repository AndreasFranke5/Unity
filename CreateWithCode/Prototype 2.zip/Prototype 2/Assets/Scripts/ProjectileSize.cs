using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileSize : MonoBehaviour
{
    // Field to store the current scale of the projectile
    private Vector3 currentScale;

    // Start is called before the first frame update
    void Start()
    {
        // Initialize the current scale to the initial scale of the projectile
        currentScale = transform.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        // Update logic if needed
    }

    // Method to increase the scale of the projectile
    public void IncreaseScale()
    {
        // Increase the scale by a small factor
        currentScale *= 1.1f; // Increase by 10%
        transform.localScale = currentScale;
    }

    // Method to handle collision with an animal
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Animal"))
        {
            // Call the method to increase the scale
            IncreaseScale();
        }
    }
}